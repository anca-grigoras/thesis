/**
 * 
 */
package vitis.pubsub;

/**
 * @author anca
 *
 */
public enum PubSubEventType {
  PUBLISH,
  TOPIC
}
/**
 * 
 */
package vitis.pubsub;

import java.io.Serializable;

import peernet.core.Descriptor;

/**
 * @author anca
 *
 */
public class PubSubEvent implements Serializable
{
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  private PubSubEventType type;
  private Descriptor src;
  private Object event;
  private static int serialNumCounter = 0;
  private long id;
  
  /**
   * 
   */
  public PubSubEvent(PubSubEventType type, Descriptor src, Object event) 
  {
    this.type = type;
    this.src = src;
    this.event = event;
    id = serialNumCounter++;
  }
  
  public long getId()
  {
    return id;
  }
  
  /**
   * @return the type
   */
  public PubSubEventType getType()
  {
    return type;
  }
  /**
   * @return the src
   */
  public Descriptor getSrc()
  {
    return src;
  }
  /**
   * @return the event
   */
  public Object getEvent()
  {
    return event;
  }
  
}

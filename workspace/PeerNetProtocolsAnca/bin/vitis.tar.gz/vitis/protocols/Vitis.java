/**
 * 
 */
package vitis.protocols;

import java.util.Collections;
import java.util.TreeSet;
import java.util.Vector;
import peernet.core.Descriptor;
import peernet.core.Linkable;
import peernet.core.Node;
import peernet.transport.Address;
import poldercast.observers.TopicPopularity;
import topics.Topic;
import topics.TopicsRepository;
import vitis.descriptor.DescriptorProfile;
import vitis.types.LeaderInfo;
import vitis.types.RelayPath;
import vitis.types.Statistics;
import vitis.messages.VitisMessage;
import gossip.descriptor.DescriptorAge;
import vitis.comparators.DescriptorComp;

/**
 * @author anca
 *
 */
public class Vitis extends Gossip
{  
  public VitisSettings vitisSettings;
  private RelayPath relayPath;

  /**
   * @param prefix
   */
  public Vitis(String prefix)
  {
    super(prefix);
    vitisSettings = (VitisSettings)settings;
    view = new Vector<Descriptor>(vitisSettings.viewSize);
    relayPath = new RelayPath();
  }

 
  /* (non-Javadoc)
   * @see peernet.core.Protocol#nextCycle(peernet.core.Node, int)
   */
  @Override
  public void nextCycle(Node node, int protocolID)
  {
    Descriptor selfDescr = createDescriptor();

    Vector<Descriptor> neighborsFromTman = collectAllNeighbors(node, selfDescr, protocolID); //get the tman view -> RT; these are the friends
    if(neighborsFromTman.isEmpty()) {
      return;
    }
    //see what's the thing with the fans
    //TreeSet<Descriptor> neighbors = new TreeSet<Descriptor>(new DescriptorComp());
    //neighbors.addAll(view);
    insertToView(neighborsFromTman);
    exchangeProfile(selfDescr, neighborsFromTman, protocolID);   
    
    
  }  

  /* (non-Javadoc)
   * @see peernet.core.Protocol#processEvent(peernet.transport.Address, peernet.core.Node, int, java.lang.Object)
   */
  @Override
  public void processEvent(Address src, Node node, int pid, Object event)
  {
    VitisMessage msg = (VitisMessage) event;
    msg.sender.address = src; // Set the sender's address
    switch (msg.type)
    {
      case REFRESH_FRIENDSHIP:
        refreshFriendship(msg.profile, node, pid);
        break;
      case SUBSCRIBE_ON_RELAY_PATH:
        subscribeOnRelayPath(msg.sender, msg.topic, msg.path, pid); //check if the sender is the requester
        break;
      case UNSUBSCRIBE_FROM_RELAY_PATH:
        unsubscribeFromRelayPath(msg.sender, msg.topic, pid);//same thing with the requester
    }   
  }  

  /**
   * @param sender
   * @param node
   */
  private void refreshFriendship(Descriptor profile, Node node, int pid)
  {
    //System.out.println(node.getID() + " refresh friendship with " + profile.getID());
    ((DescriptorAge)profile).resetAge();
    Descriptor selfDescr = createDescriptor();
    Vector<Descriptor> neighbors = collectAllNeighbors(node, selfDescr, pid); //get the tman view -> RT; these are the friends
    neighbors.add(profile);
    insertToView(neighbors);

    updateProfile(selfDescr, neighbors, pid);
    refreshRelayPath(selfDescr, neighbors, pid);

  }  

  /**
   * @param requester
   * @param topic
   * @param path
   */
  private void subscribeOnRelayPath(Descriptor requester, Topic topic, Vector<Descriptor> path, int pid)
  {
    Descriptor selfDescr = createDescriptor();
    
    Descriptor toUnsubscribe;
    this.relayPath.addRelayTo(topic, requester);

    if (!((DescriptorProfile)selfDescr).getTopics().contains(topic) && this.relayPath.getReceiveFrom(topic) == null) {
      //Vector<Descriptor> neighborsFromTman = collectAllNeighbors(node, selfDescr, pid);
      Vector<Descriptor> neighbors = view;
      neighbors.add(selfDescr);
      Collections.sort(neighbors, new DescriptorComp());
      Descriptor nextHop = findNextHop(topic, neighbors);
      
      if(path.contains(nextHop) || nextHop.equals(selfDescr))
        return;
      else {
        path.add(selfDescr);
        //System.out.println(node.getID() + " recursion: " + path.size());
        toUnsubscribe = this.relayPath.addRelayRequest(topic, nextHop);
        
        //SEND TO NEXTHOP A REQUEST TO SUBSCRIBE ON RELAY PATH: (SELFDESCR, TOPIC, PATH) 
        sendRequest(selfDescr, nextHop, VitisMessage.Type.SUBSCRIBE_ON_RELAY_PATH, topic, path, pid);
        
        if (toUnsubscribe != null && !toUnsubscribe.equals(nextHop))
          sendRequest(selfDescr, nextHop, VitisMessage.Type.UNSUBSCRIBE_FROM_RELAY_PATH, topic, null, pid);
      }
    } 
  }

  /**
   * @param sender
   * @param topic
   */
  private void unsubscribeFromRelayPath(Descriptor requester, Topic topic, int pid)
  {
    Descriptor selfDescr = createDescriptor();
    Descriptor toUnsubscribe = this.relayPath.removePath(topic, requester, selfDescr);
    if (toUnsubscribe != null)
      sendRequest(selfDescr, toUnsubscribe, VitisMessage.Type.UNSUBSCRIBE_FROM_RELAY_PATH, topic, null, pid);
    //System.out.println("I unsubscribed");
  }

 
  private void exchangeProfile(Descriptor selfDescr, Vector<Descriptor> neighbors, int pid) {
    updateProfile(selfDescr, neighbors, pid);
    refreshRelayPath(selfDescr, neighbors, pid);

    //see what's the thing with the old friends. we just remove them or we also send a 'stop friendship' message

    //send the profile to the alive friends ????
    for (Descriptor d : neighbors)
    {
      if (d.equals(selfDescr))
        continue;
      if (((DescriptorAge)d).getAge() > vitisSettings.threshold)
        view.remove(d);
      else {
        ((DescriptorAge)d).incAge();
        VitisMessage msg = new VitisMessage();
        msg.sender = selfDescr;
        msg.profile = selfDescr;
        msg.type = VitisMessage.Type.REFRESH_FRIENDSHIP;
        send(d.address, pid, msg);
      }
    }

  }

  private void updateProfile(Descriptor selfDescr, Vector<Descriptor> neighbors, int pid)
  {
    ((DescriptorProfile)selfDescr).setLeaders(selfDescr, neighbors); //update your own profile
    //printLeaders(selfDescr);


    //if you are a leader (gateway) subscribe on the replay path, otherwise make sure you are not subscribed on any path
    Vector<Descriptor> path;
    Descriptor nextHop, toUnsubscribe;

    neighbors.add(selfDescr);
    Collections.sort(neighbors, new DescriptorComp());

    for (Topic topic : ((DescriptorProfile)selfDescr).getTopics())
    {
      Descriptor leader = ((DescriptorProfile)selfDescr).getLeader(topic);
      if (selfDescr.equals(leader)) //if it's the leader
      {
        //System.out.print(node.getID() + " " + topic.getId() + " I am the leader ");
        nextHop = findNextHop(topic, neighbors);
        if (!nextHop.equals(selfDescr)) //and it's not the rendezvous point
        {
          toUnsubscribe = this.relayPath.addRelayRequest(topic, nextHop);
          path = new Vector<Descriptor>();
          path.add(selfDescr);
          //SEND TO NEXTHOP A REQUEST TO SUBSCRIBE ON RELAY PATH: (SELFDESCR, TOPIC, PATH) 
          sendRequest(selfDescr, nextHop, VitisMessage.Type.SUBSCRIBE_ON_RELAY_PATH, topic, path, pid);

          if (toUnsubscribe != null && !toUnsubscribe.equals(nextHop))
          {
            //SEND TO TOUNSUBSCRIBE A REQUEST TO UNSUBSCRIBE FROM RELAY PATH: (SELFDESCR, TOPIC);
            sendRequest(selfDescr, toUnsubscribe, VitisMessage.Type.UNSUBSCRIBE_FROM_RELAY_PATH, topic, null, pid);
          }
          //System.out.println("but not the rendezvous point");
        } else
          if ((toUnsubscribe = this.relayPath.getReceiveFrom(topic)) != null) { //but if it is the rendezvous point
            //System.out.println("and also the rendezvous point");
            this.relayPath.removeRelayRequest(topic);
            //SEND TO TOUNSUBSCRIBE A REQUEST TO UNSUBSCRIBE FROM RELAY PATH: (SELFDESCR, TOPIC);
            sendRequest(selfDescr, toUnsubscribe, VitisMessage.Type.UNSUBSCRIBE_FROM_RELAY_PATH, topic, null, pid);
          }
      } else if ((toUnsubscribe = this.relayPath.getReceiveFrom(topic)) != null) { //but if it's not the leader
        this.relayPath.removeRelayRequest(topic);
        //SEND TO TOUNSUBSCRIBE A REQUEST TO UNSUBSCRIBE FROM RELAY PATH: (SELFDESCR, TOPIC);
        sendRequest(selfDescr, toUnsubscribe, VitisMessage.Type.UNSUBSCRIBE_FROM_RELAY_PATH, topic, null, pid);
      }
    }
  }

  private void refreshRelayPath(Descriptor selfDescr, Vector<Descriptor> neighbors, int pid) {
    //refresh the relay path
     Descriptor nextHop = null;
    Descriptor toUnsubscribe = null;
    Vector<Descriptor> path;

    ((DescriptorProfile)selfDescr).clearRelayInterests();

    for (Topic topic : this.relayPath.getRelayTopics()) {
      if (!((DescriptorProfile)selfDescr).getTopics().contains(topic)) {
        ((DescriptorProfile)selfDescr).addRelayInterest(topic);
        nextHop = findNextHop(topic, neighbors);

        //if it's not the rendezvous point and the next relay node is a new one
        if (!nextHop.equals(selfDescr) && (this.relayPath.getReceiveFrom(topic) == null ||!nextHop.equals(this.relayPath.getReceiveFrom(topic)))) {
          toUnsubscribe = this.relayPath.addRelayRequest(topic, nextHop);
          path = new Vector<Descriptor>();
          path.add(selfDescr);
          //SEND TO NEXTHOP A REQUEST TO SUBSCRIBE ON RELAY PATH: (SELFDESCR, TOPIC, PATH)
          sendRequest(selfDescr, nextHop, VitisMessage.Type.SUBSCRIBE_ON_RELAY_PATH, topic, path, pid);

          if (toUnsubscribe != null && !toUnsubscribe.equals(nextHop)) {
            //SEND TO TOUNSUBSCRIBE A REQUEST TO UNSUBSCRIBE FROM RELAY PATH: (SELFDESCR, TOPIC);
            sendRequest(selfDescr, toUnsubscribe, VitisMessage.Type.UNSUBSCRIBE_FROM_RELAY_PATH, topic, null, pid);
          }
        }
      }
    }
  }

  /**
   * @param topic
   * @param neighbors
   * @return
   */
  private Descriptor findNextHop(Topic topic, Vector<Descriptor> neighbors)
  {
    Descriptor nextHop = neighbors.firstElement();

    for (Descriptor d : neighbors)
      if ((int)d.getID() > topic.getId())
      {
        nextHop = d;
        break;
      }

    return nextHop;
  }

  /**
   * Puts together all neighbors of this protocol and all linked protocols.
   * Descriptors are NOT necessarily cloned. The idea is that preparing a
   * collection of all neighbors should be fast, and cloning should be mandatory
   * when selecting out of these neighbors either to feed my view, or to send
   * to my peer.
   * 
   * @param selfNode
   * @param selfDescr
   * @param pid
   * @return Returned descriptors are NOT guaranteed to be cloned.
   */
  private Vector<Descriptor> collectAllNeighbors(Node selfNode, Descriptor selfDescr, int pid)
  {
    // If no protocols are linked, return the view, as is.
    if (!settings.hasLinkable())
      return view;

    Vector<Descriptor> neighborsFromAllProtocols = new Vector<Descriptor>();

    // Then collect neighbors from linked protocols
    for (int i=0; i<settings.numLinkables(); i++)
    {
      int linkableID = settings.getLinkable(i);
      Linkable linkable = (Linkable) selfNode.getProtocol(linkableID);
      // Add linked protocol's neighbors
      for (int j = 0; j<linkable.degree(); j++)
      {
        // We have to clone it, to change its hops without affecting Cyclon.
        Descriptor descr = (Descriptor) linkable.getNeighbor(j);
        if(!neighborsFromAllProtocols.contains(descr))
        {
          Descriptor d = null;
          d = (Descriptor) descr.clone();
          neighborsFromAllProtocols.add(d);
        }
      }
    }    
    return neighborsFromAllProtocols;
  }

  private void sendRequest(Descriptor sender, Descriptor receiver, VitisMessage.Type type, Topic topic, Vector<Descriptor> path, int pid)
  {
    VitisMessage msg = new VitisMessage();
    msg.sender = sender;
    msg.type = type;
    msg.topic = topic;
    if (type.toString().equals("SUBSCRIBE_ON_RELAY_PATH"))
      msg.path = path;
    send(receiver.address, pid, msg);
  }
  
  private void insertToView(Vector<Descriptor> peers)
  {
    view.clear();
    for (Descriptor d : peers)
    {
      view.add(d);
    }
  }
  
  public Vector<Descriptor> getRelayNeighbors(Topic topic)
  {
    return relayPath.getRelayNeighbors(topic);
  }

  private void printLeaders(Descriptor self) {
    System.out.print(self.getID() + " : ");
    for (Topic t : ((DescriptorProfile)self).getTopics())
    {
      Descriptor leader = ((DescriptorProfile)self).getLeader(t);
      System.out.print("<"+t.getId()+","+leader.getID()+">   ");
    }
    System.out.println();
  }
  
 
  /* (non-Javadoc)
   * @see peernet.core.Linkable#addNeighbor(peernet.core.Descriptor)
   */
  @Override
  public boolean addNeighbor(Descriptor neighbour)
  {
    if (contains(neighbour))
      return false;

    if (view.size() >= vitisSettings.viewSize)
      throw new IndexOutOfBoundsException();

    view.add(neighbour);
    return true;
  }
}

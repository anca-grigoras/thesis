/**
 * 
 */
package vitis.protocols;

import java.util.HashMap;
import java.util.Vector;

import peernet.core.CommonState;
import peernet.core.Descriptor;
import peernet.core.Linkable;
import peernet.core.Node;
import peernet.core.Protocol;
import peernet.transport.Address;
import topics.Topic;
import vitis.descriptor.DescriptorProfile;
import vitis.observers.NetworkObserver;
import vitis.protocols.Dissemination;
import vitis.protocols.DisseminationSettings;
import vitis.pubsub.PubSubEvent;
import vitis.pubsub.PubSubEventType;
import vitis.pubsub.PublishEvent;
import vitis.pubsub.TopicEvent;
import vitis.types.Statistics;
import topics.TopicsRepository;

/**
 * @author anca
 *
 */
public class Dissemination extends Protocol
{
  public HashMap<Long, Integer> messageDigest;
  boolean isInitialized = false;
  DisseminationSettings disSettings;
  HashMap<Topic, Boolean> topicMessageFwd;
  private Vector<TopicEvent> receivedEvents;
  private Vector<TopicEvent> recentEvents;
  private Statistics statistics;
  private final long joiningTime;
  
  
  private HashMap<TopicEvent, Long> receivedMessages;
  
  /**
   * @param prefix
   */
  public Dissemination(String prefix)
  {
    super(prefix);
    messageDigest = new HashMap<Long, Integer>();
    disSettings = (DisseminationSettings)settings;
    topicMessageFwd = new HashMap<Topic, Boolean>();
    receivedEvents = new Vector<TopicEvent>();
    recentEvents = new Vector<TopicEvent>();
    statistics = new Statistics();
    joiningTime = CommonState.getTime();
    
    receivedMessages = new HashMap<TopicEvent,Long>();
    
  }
 
  
  /* (non-Javadoc)
   * @see peernet.core.Protocol#processEvent(peernet.transport.Address, peernet.core.Node, int, java.lang.Object)
   */
  @Override
  public void processEvent(Address src, Node node, int pid, Object event)
  {
    PubSubEvent pubsubEvent = (PubSubEvent)event;
    
    switch(pubsubEvent.getType()) {
      case PUBLISH:
        handlePublish(node, pubsubEvent.getSrc(), (PublishEvent)pubsubEvent.getEvent(), pid);
        break;
      case TOPIC:
        handleTopic(node, pubsubEvent.getSrc(), (TopicEvent)pubsubEvent.getEvent(), pid);
    }
  }

  /**
   * @param node 
   * @param src
   * @param event
   * @param pid
   */
  private void handlePublish(Node node, Descriptor src, PublishEvent event, int pid)
  {
    Topic topic = event.getTopic();
    Descriptor selfDescr = createDescriptor();
    Vector<Descriptor> path = new Vector<Descriptor>();
    //path.add(selfDescr);
    TopicEvent topicEvent = new TopicEvent(topic, selfDescr, "new event", path);
    PubSubEvent newEvent = new PubSubEvent(PubSubEventType.TOPIC, selfDescr, topicEvent);
    
    //receivedMessages.put(topicEvent, CommonState.getTime());
    
    NetworkObserver.addPublishedEvent(topicEvent);
    
    this.receivedEvents.add(topicEvent);
    this.recentEvents.add(topicEvent);
    Vector<Descriptor> interestedPeers = findInterestedPeers(node, pid, selfDescr, topic);
    
    for (Descriptor d : interestedPeers) {
      send(d.address, pid, newEvent);
      //System.out.println(selfDescr.getID() + " sent a msg to " + d.getID());
    }
  }

 


  /**
   * @param node 
   * @param src
   * @param event
   * @param pid
   */
  private void handleTopic(Node node, Descriptor src, TopicEvent event, int pid)
  {
    if (this.receivedEvents.contains(event))
    {
      //System.out.println("duplicate");
      //still store it for counting the duplicates
      return;
    }
    //receivedMessages.put(event, CommonState.getTime());
    this.receivedEvents.add(event);
    this.recentEvents.add(event);
    
    Descriptor self = createDescriptor();
    
    Topic topic = event.getTopic();
   
    TopicEvent newTe = (TopicEvent) event.clone();
    newTe.incrementHopCounts();
    Vector<Descriptor> path = new Vector<Descriptor>();
    path.addAll(event.getPath());
    path.add(self);
    newTe.setPath(path);
    
   
    //if (node.getID() == 5) System.out.println("The size of received events for node 5 is : "+this.receivedEvents.size() + " from " + src.getID());
    PubSubEvent pse = new PubSubEvent(PubSubEventType.TOPIC, self, newTe);
    
    Vector<Descriptor> interestedPeers = findInterestedPeers(node, pid, self, topic);
    
    for (Descriptor d : interestedPeers)
    {
      send(d.address, pid, pse);
      //System.out.println(self.getID() + " sent a topic msg to " + d.getID());
    }
    
  }
  
  private Vector<Descriptor> findInterestedPeers(Node node, int pid, Descriptor self, Topic topic)
  {
    Vector<Descriptor> interestedPeers = new Vector<Descriptor>();
    
    Vector<Descriptor> friends = collectAllNeighbors(node, self, pid);
    
    if (friends != null)
      for (Descriptor d : friends)
      {
        if (((DescriptorProfile)d).isSubscribedTo(topic))
          interestedPeers.add(d);
        if (((DescriptorProfile)d).getRelayInterests().contains(topic))
          if (!interestedPeers.contains(d))
            interestedPeers.add(d);
      }
    
    Vitis vitis = (Vitis) node.getProtocol(disSettings.rtPid);
    if (vitis.getRelayNeighbors(topic) != null) {
      for (Descriptor d : vitis.getRelayNeighbors(topic)) {
        if (d != null) {
          if (!interestedPeers.contains(d))
            interestedPeers.add(d);
        }
      }
    }
    
    interestedPeers.remove(self);
    //interestedPeers.remove(src);
    
    return interestedPeers;
  }
  
  public HashMap<TopicEvent, Long> getReceivedMessages()
  {
    return this.receivedMessages;
  }
  
  public void resetReceivedMessages()
  {
    this.receivedMessages.clear();
  }
  
  public Statistics getStatistics() {
    int relayEvents = 0;
    int relevantEvents = 0;
    int hopCounts = 0;
    float coverage = 1;
    
    int numOfPublishedEvents = 0;
    int size;
    
    Vector<Topic> myTopics = TopicsRepository.getTopics(node.getID());
    size = this.receivedEvents.size();
    
    for (TopicEvent event : this.receivedEvents) {
      if (!myTopics.contains(event.getTopic()))
        relayEvents++;
      else {
        hopCounts += event.getHopCounts();
        relevantEvents++;
      }
    }
    
    numOfPublishedEvents = myTopics.size(); //one event per topic
    
    coverage = (numOfPublishedEvents == 0 ? 1 : (float)size/(float)numOfPublishedEvents);
    
    this.statistics.setNumReceivedEvents(size);
    if (size > 0) {
      this.statistics.setRelayTraffic(relayEvents*100/size);
      this.statistics.setAvgHopCounts(relevantEvents > 0 ? hopCounts/relevantEvents : 0);
      this.statistics.setCoverage(coverage);
    }else {
      this.statistics.setRelayTraffic(0);
      this.statistics.setAvgHopCounts(0);
      this.statistics.setCoverage(1);
    }
    
    return this.statistics;
  }

  /* (non-Javadoc)
   * @see peernet.core.Protocol#nextCycle(peernet.core.Node, int)
   */
  @Override
  public void nextCycle(Node node, int protocolID)
  {
    // TODO Auto-generated method stub
  }
  
  /**
   * @return the messageDigest
   */
  public HashMap<Long, Integer> getMessageDigest()
  {
    return messageDigest;
  }

  /**
   * @return the isInitialized
   */
  public boolean isInitialized()
  {
    return isInitialized;
  }
  /**
   * @return the topicMessageFwd
   */
  public HashMap<Topic, Boolean> getTopicMessageFwd()
  {
    return topicMessageFwd;
  }
  
  public void setEventState(Topic topic)
  {
    topicMessageFwd.put(topic, false);
  }


  /**
   * @return the disSettings
   */
  public DisseminationSettings getDisSettings()
  {
    return disSettings;
  }
  
  private Vector<Descriptor> collectAllNeighbors(Node selfNode, Descriptor selfDescr, int pid)
  {
    // If no protocols are linked, return the view, as is.
    if (!settings.hasLinkable())
      return null;

    Vector<Descriptor> neighborsFromAllProtocols = new Vector<Descriptor>();

    // Then collect neighbors from linked protocols
    for (int i=0; i<settings.numLinkables(); i++)
    {
      int linkableID = settings.getLinkable(i);
      Linkable linkable = (Linkable) selfNode.getProtocol(linkableID);
      // Add linked protocol's neighbors
      for (int j = 0; j<linkable.degree(); j++)
      {
        // We have to clone it, to change its hops without affecting Cyclon.
        Descriptor descr = (Descriptor) linkable.getNeighbor(j);
        if(!neighborsFromAllProtocols.contains(descr))
        {
          Descriptor d = null;
          d = (Descriptor) descr.clone();
          neighborsFromAllProtocols.add(d);
        }
      }
    }    
    return neighborsFromAllProtocols;
  }

  public long getJoiningTime() {
    return this.joiningTime;
  }

  public Vector<TopicEvent> getReceivedEvents() {
    return this.receivedEvents;
  }
  
  @Override
  public Object clone()
  {
    Dissemination diss = null;
    diss = (Dissemination) super.clone();
    diss.messageDigest = (HashMap<Long, Integer>)messageDigest.clone();
    diss.isInitialized = false;
    diss.topicMessageFwd = (HashMap<Topic,Boolean>) topicMessageFwd.clone();
    diss.receivedEvents = (Vector<TopicEvent>)receivedEvents.clone();
    diss.recentEvents = (Vector<TopicEvent>)recentEvents.clone();
    
    diss.receivedMessages = (HashMap<TopicEvent, Long>)receivedMessages.clone();
    
    return diss;
  }
}

/**
 * 
 */
package vitis.observers;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import netsize.MyMinTopK;

import peernet.config.Configuration;
import peernet.core.CommonState;
import peernet.core.Control;
import peernet.core.Descriptor;
import peernet.core.Network;
import peernet.core.Node;
import topics.Topic;
import topics.TopicsRepository;
import vitis.protocols.Dissemination;
import vitis.pubsub.TopicEvent;
import vitis.types.Statistics;

/**
 * @author anca
 *
 */
public class NetworkObserver implements Control
{
  private int cycle = 0;
  private int pid;
  private int size;
  private static HashMap<Topic,Vector<TopicEvent>> publishedEvents = new HashMap<Topic, Vector<TopicEvent>>();
  /**
   * 
   */
  public NetworkObserver(String name)
  {
    pid = Configuration.getPid(name+"."+PAR_PROTOCOL);
    size = TopicsRepository.getAllTopics().size();
  }



  /* (non-Javadoc)
   * @see peernet.core.Control#execute()
   */
  @Override
  public boolean execute()
  {
    cycle++;
    //System.out.println("cycle "+cycle + ": " + CommonState.getTime());
    doMeasurements();
    
    return false;
  }



  /**
   * 
   */
  private void doMeasurements()
  {
    Dissemination diss;
    
    Statistics nodeStatistics;
    float relayTraffic;
    float totalRelayTraffic = 0;
    float avgHopCounts;
    float totalHopCounts = 0;
    Vector<TopicEvent> relevantEvents = new Vector<TopicEvent>();
    int numRelevantEvents;
    float missingEventsPercentage;
    float hitRatio;
    float totalMissRatio = 0;
//    int numberOfReceiverNodes = 0;
    int numberOfRelevantNodes = 0;
    int netSize = Network.size();
    HashMap<Topic,Integer> hits = new HashMap<Topic, Integer>();
 
    for (int i = 0; i< netSize; i++)
    {
      Node n = Network.get(i);
      Vector<Topic> myTopics = TopicsRepository.getTopics(n.getID());
      diss = (Dissemination)n.getProtocol(pid);
      
      HashMap<TopicEvent,Long> myMsg = diss.getReceivedMessages();
      Set<Entry<TopicEvent,Long>> set = myMsg.entrySet();
      Iterator<Entry<TopicEvent,Long>> it = set.iterator();     
      
      while(it.hasNext())
      {
        /*String path="<";
        Entry<TopicEvent,Long> entry = it.next();
        
        for (Descriptor d : entry.getKey().getPath())
          path += d.getID() + ", ";
        path +=">";
        
        String line = n.getID() + " \t" + 
                      entry.getKey().getId() + " \t" +
                      entry.getKey().getTopic().getId() + " \t" +
                      entry.getKey().getHopCounts() + " \t" + 
                      entry.getValue() + "\t" +
                      path;
       // System.out.println(line);*/
      }
      //diss.resetReceivedMessages();
          
      nodeStatistics = diss.getStatistics();
      
      relayTraffic = nodeStatistics.getRelayTraffic();
      totalRelayTraffic += relayTraffic;
      
      
      avgHopCounts = nodeStatistics.getAvgHopCounts();
      totalHopCounts += avgHopCounts;
      if (avgHopCounts > 0) // we don't count the hops for relay nodes, so we should exclude them here too
        numberOfRelevantNodes++;
      
      relevantEvents.clear();
      for (Topic topic : myTopics)
        if (publishedEvents.get(topic) != null)
          relevantEvents.addAll(getPublishedEvents(topic));
      
      numRelevantEvents = relevantEvents.size();
      //if (numberOfRelevantNodes > 0) System.out.println(n.getID() + " " + numberOfRelevantNodes);
      
      //relevantEvents.removeAll(diss.getReceivedEvents());
      for (TopicEvent te : diss.getReceivedEvents())
      {
        if (relevantEvents.contains(te))
        {
          relevantEvents.remove(te);
          /*if (hits.get(te.getTopic()) == null)
            hits.put(te.getTopic(), 1);
          else{
            int h = hits.get(te.getTopic()) + 1;
            hits.put(te.getTopic(), h);
          }*/
        } 
      }
      missingEventsPercentage = (numRelevantEvents > 0 ? relevantEvents.size()*100/numRelevantEvents : 0);
      totalMissRatio+=missingEventsPercentage;
      hitRatio = 100-missingEventsPercentage;
      String str = "node: " + n.getID() + "\t%relay traffic: " + relayTraffic + "\tavg hop counts: " + avgHopCounts +
          "\t%hitRatio: " + hitRatio + "\t#received events: " +  diss.getReceivedEvents().size() + "\t#relevant events: " + numRelevantEvents +
          "\t topics: " + myTopics.size();
      //System.out.println(str);
      //diss.getReceivedEvents().clear();
    }
    
    /*Set<Entry<Topic,Integer>> set = hits.entrySet();
    Iterator<Entry<Topic,Integer>> it = set.iterator();
    
    int completeDis = 0;
    while (it.hasNext())
    {
      Entry<Topic, Integer> entry = it.next();
      if (entry.getValue() == TopicsRepository.getSubscribers(entry.getKey()).size())
          completeDis++;
    }
    
    double msgDiss = 100-(double)completeDis/size*100;*/
    System.out.println(cycle-1 + "\t" + totalMissRatio/netSize + "\t");
    //publishedEvents.clear();
  }
  
  public Vector<TopicEvent> getPublishedEvents(Topic topic) {
    long maxTime = 0;
    Vector<TopicEvent> eventsOnThisTopic = publishedEvents.get(topic);
    Vector<TopicEvent> relevantPublishedEvents = new Vector<TopicEvent>();
    if (eventsOnThisTopic != null) {
      for (TopicEvent event: eventsOnThisTopic)
        if (event.getTime() > maxTime)
        {
          relevantPublishedEvents.clear();
          maxTime = event.getTime();
          relevantPublishedEvents.add(event);
        }
        else if (event.getTime() == maxTime)       
          relevantPublishedEvents.add(event);
    }

    return relevantPublishedEvents;
  }
  
  /**
   * @param topicEvent
   */
  public static void addPublishedEvent(TopicEvent topicEvent)
  {
    Topic topic = topicEvent.getTopic();
    
    if (!publishedEvents.containsKey(topic))
      publishedEvents.put(topic, new Vector<TopicEvent>());
    
    publishedEvents.get(topic).add(topicEvent);
    
  }
}
